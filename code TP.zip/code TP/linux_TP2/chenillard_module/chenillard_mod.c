#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>

#define DRIVER_AUTHOR "Christophe Barès"
#define DRIVER_DESC "Hello world Module"
#define DRIVER_LICENSE "GPL"

const char *ensea_name = "ensea";
const char *chenille_name = "chenille";
int ledState = 0;
int TAILLE = 50;
char message[100];
int size_of_message = 0;

static int param;
struct timer_list timer;

static struct proc_dir_entry *ensea_entry;
static struct proc_dir_entry *chenille_entry;


ssize_t fops_read(struct file *file, char __user *buffer, size_t count, loff_t *ppos)
{
	int errno = 0;
	int copy;
	if (count > TAILLE)
		count = TAILLE;
	if ((copy = copy_to_user(buffer, message, strlen(message) + 1)))
		errno = -EFAULT;
	printk(KERN_INFO "message read, %d, %p\n", copy, buffer);
	return count - copy;
}

ssize_t fops_write(struct file *file, const char __user *buffer, size_t count, loff_t *ppos)
{
	int len = count;
	if (len > TAILLE)
		len = TAILLE;
	printk(KERN_INFO "Recieving new messag\n");
	if (copy_from_user(message, buffer, count))
	{
		return -EFAULT;
	}
	message[count] = '\0';
	size_of_message = strlen(message);
	printk(KERN_INFO "New message : %s\n", message);
	return count;
}

static struct file_operations proc_fops = {
	.owner=THIS_MODULE,
	.read = fops_read,
	.write = fops_write,
};


static void montimer(struct timer_list *t)
{
	// callback du timer
	ledState = 1 - ledState;
	printk(KERN_INFO "ledState : %d\n\r", ledState);

	/* Il faut réarmer le timer si l'on veut un appel périodique */
	mod_timer(&timer, jiffies + param);
}

static int chenillard_init(void)
{
	// creation du fichier dans /proc/ensea/chenille
	//  creation partie proc ensea
	ensea_entry = proc_mkdir(ensea_name,ensea_entry);
	// creation de du fichier chenille dans proc/ensea/
	chenille_entry = proc_create(chenille_name, 0666,ensea_entry, &proc_fops);

	// setup timer
	setup_timer(&timer, montimer, 0);
	// demarrage timer
	mod_timer(&timer, jiffies + param);
	printk(KERN_INFO "module chargé, timer démarré\r\n");
	return 0;
}

void chenillard_exit(void){
	remove_proc_entry(chenille_name,chenille_entry);
	remove_proc_entry(ensea_name,ensea_entry);
	del_timer (&timer);
	printk(KERN_ALERT "Bye bye...\n");
	printk(KERN_INFO "module déchargé\r\n");
}


module_param(param, int, 0);
MODULE_PARM_DESC(param, "Un paramètre de ce module");

int hello_init(void)
{
	printk(KERN_INFO "chenillard hello\n");
	printk(KERN_INFO "Parametre : %d\r\n", param);
	return 0;
}


module_init(chenillard_init);
module_exit(chenillard_exit);

MODULE_LICENSE(DRIVER_LICENSE);
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);

#include <sys/mman.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>      // important pour qu'il reconnaise les type genre uint8_t
#include <sys/wait.h>

#define ADRESSE_GPIO 0xFF203000

// fonction custom avec gestion erreur intégré 
uint8_t write_peripheral(uint32_t adresse_peripheral,uint8_t numero_LED,uint8_t state){

    uint32_t * p;
    int fd = open("/dev/mem", O_RDWR);      // open the mem mapping file
    if(fd==-1){
        printf("erreur file opening !\r\n");
        return 1;
    }

    p = (uint32_t*)mmap(NULL, 4, PROT_WRITE|PROT_READ, MAP_SHARED,fd, adresse_peripheral);
    if(p==MAP_FAILED){
        printf("erreur : mmap failed !\r\n");
        return 1;
    }
    *p = (state<<numero_LED);
    return 0;
}

int main(int argc, char **argv){
    uint8_t state=1;
    uint8_t ret=0;
    //toggle la led 1 normalement avec un delay de 1 sec
    while(1){
    if((ret=write_peripheral(ADRESSE_GPIO,3,state))!=0){
        printf("erreur\r\n");
    }
    state=1-state;
    usleep(100000);    // delay en us
    }
    return 0;
}


#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/platform_device.h>
#include <linux/io.h>
#include <linux/miscdevice.h>
#include <linux/types.h>

#define DRIVER_AUTHOR "Baptiste Cottu Diego Jaimes"
#define DRIVER_DESC "Module final"
#define DRIVER_LICENSE "GPL"
#define BUF_LEN 64
#define DirectionLen 1

int ledState = 0;
int TAILLE = 50;
size_t lus;

const char *ensea_name = "ensea";
const char *speed_name = "speed";
const char *dir_name = "dir";

static int speed_param=200;
static int dir_param;
struct timer_list timer;

// ------ Entrée dans proc -----

// declaration des entrées créées
static struct proc_dir_entry *ensea_entry;
static struct proc_dir_entry *speed_entry;
static struct proc_dir_entry *dir_entry;

// declaration read speed_fops
uint8_t speed_taille = 20;
static ssize_t speed_fops_read(struct file *file, char *speed_buf, size_t count, loff_t *ppos){
    char buff[1000];
    int len;
    int errno=0;
    uint16_t size_of_buff=0;

    len = sprintf(buff, "%d\n", speed_param);
    if (*ppos >= len)
        return 0;
    if (count > len - *ppos)
        count = len - *ppos;

    if(copy_to_user(speed_buf, (int *)&buff, len)){
        errno=-EFAULT;
    }

    buff[len] = '\0';
    size_of_buff = strlen(buff);

    *ppos += count;
    return len;
}

// declaration read/write dir_fops

static ssize_t dir_read_function(struct file *file, char *buf, size_t count, loff_t *ppos)
{
    char buff[128];
    int len;
    int errno=0;

    len = sprintf(buff, "%d\n", dir_param);
    if (*ppos >= len)
        return 0;
    if (count > len - *ppos)
        count = len - *ppos;

    if(copy_to_user(buf, (int *)&buff, len)){
        errno=-EFAULT;
    };

    printk("Lecture de la direction\n");
    *ppos += count;
    return len;
}

static ssize_t dir_write_function(struct file *file, char *buf, size_t count, loff_t *ppos)
{
    char buffer[128];

    if(copy_from_user((int *)buffer, buf, DirectionLen)){
        return -EFAULT;
    };

    if (buffer[0] == '0')
        dir_param = 0;
    if (buffer[0] == '1')
        dir_param = 1;
    else
        printk("Please choose between 0 & 1\n");

    return DirectionLen;
}

// declaration dread/write proc_fops
ssize_t proc_fops_read(struct file *file, char *buffer, size_t count, loff_t *ppos)
{
    char proc_message_read[1000];
    int errno = 0;
    int copy;
    if (count > TAILLE)
        count = TAILLE;
    if ((copy = copy_to_user(buffer, (int *)&proc_message_read, strlen(proc_message_read) + 1)))
        errno = -EFAULT;
    return count - copy;
}

ssize_t proc_fops_write(struct file *file, const char *buffer, size_t count, loff_t *ppos)
{
    char proc_message_write[1000];
    uint16_t size_of_message=0; 
    int len = count;
    if (len > TAILLE)
        len = TAILLE;
    if (copy_from_user((int *)&proc_message_write, buffer, count))
    {
        return -EFAULT;
    }
    proc_message_write[count] = '\0';
    size_of_message = strlen(proc_message_write);
    return count;
}


// liaison des read/write aux fichiers correspondants


static struct file_operations proc_fops = {
    .owner = THIS_MODULE,
    .read = proc_fops_read,
    .write = proc_fops_write,
};

static struct file_operations speed_fops = {
    .owner = THIS_MODULE,
    .read = speed_fops_read,
};

static struct file_operations dir_fops = {
    .owner = THIS_MODULE,
    .read = dir_read_function,
    .write = dir_write_function,
};



// ----- Driver LED ------ (pas testé a partir d'ici mais compile sans erreures)

static int leds_probe(struct platform_device *pdev);
static int leds_remove(struct platform_device *pdev);
static ssize_t leds_read(struct file *file, char *buffer, size_t len, loff_t *offset);
static ssize_t leds_write(struct file *file, const char *buffer, size_t len, loff_t *offset);

// structure du device
struct ensea_leds_dev {
    struct miscdevice miscdev;
    void __iomem *regs;
    u8 leds_value;
};

// Specify which device tree devices this driver supports
static struct of_device_id ensea_leds_dt_ids[] = {
    {
        .compatible = "dev,ensea"
    },
    { /* end of table */ }
};

// Inform the kernel about the devices this driver supports
MODULE_DEVICE_TABLE(of, ensea_leds_dt_ids);

// structure fops ensea-led
static ssize_t leds_read(struct file *file, char *buffer, size_t len, loff_t *offset)
{
    int success = 0;
    struct ensea_leds_dev *dev = container_of(file->private_data, struct ensea_leds_dev, miscdev);

    // Give the user the current led value
    success = copy_to_user(buffer, &dev->leds_value, sizeof(dev->leds_value));

    // If we failed to copy the value to userspace, display an error message
    if(success != 0) {
        pr_info("Failed to return current led value to userspace\n");
        return -EFAULT; // Bad address error value. It's likely that "buffer" doesn't point to a good address
    }

    return 0; // "0" indicates End of File, aka, it tells the user process to stop reading
}

static ssize_t leds_write(struct file *file, const char *buffer, size_t len, loff_t *offset)
{
    int success = 0;
    struct ensea_leds_dev *dev = container_of(file->private_data, struct ensea_leds_dev, miscdev);

    // Get the new led value (this is just the first byte of the given data)
    success = copy_from_user(&dev->leds_value, buffer, sizeof(dev->leds_value));

    // If we failed to copy the value from userspace, display an error message
    if(success != 0) {
        pr_info("Failed to read led value from userspace\n");
        return -EFAULT; // Bad address error value. It's likely that "buffer" doesn't point to a good address
    } else {
        // We read the data correctly, so update the LEDs
        iowrite32(dev->leds_value, dev->regs);
    }

    // Tell the user process that we wrote every byte they sent
    // (even if we only wrote the first value, this will ensure they don't try to re-write their data)
    return len;
}

static const struct file_operations ensea_leds_fops = {
    .owner = THIS_MODULE,
    .read = leds_read,
    .write = leds_write
};

// structure led plateforme
static int leds_probe(struct platform_device *pdev)
{
    int ret_val = -EBUSY;
    struct ensea_leds_dev *dev;
    struct resource *r = 0;

    pr_info("leds_probe enter\n");

    // Get the memory resources for this LED device
    r = platform_get_resource(pdev, IORESOURCE_MEM, 0);
    if(r == NULL) {
        pr_err("IORESOURCE_MEM (register space) does not exist\n");
        goto bad_exit_return;
    }

    // Create structure to hold device-specific information (like the registers)
    dev = devm_kzalloc(&pdev->dev, sizeof(struct ensea_leds_dev), GFP_KERNEL);

    // Both request and ioremap a memory region
    // This makes sure nobody else can grab this memory region
    // as well as moving it into our address space so we can actually use it
    dev->regs = devm_ioremap_resource(&pdev->dev, r);
    if(IS_ERR(dev->regs))
        goto bad_ioremap;

    // Turn the LEDs on (access the 0th register in the ensea LEDs module)
    dev->leds_value = 0xFF;
    iowrite32(dev->leds_value, dev->regs);

    // Initialize the misc device (this is used to create a character file in userspace)
    dev->miscdev.minor = MISC_DYNAMIC_MINOR;    // Dynamically choose a minor number
    dev->miscdev.name = "ensea_leds";
    dev->miscdev.fops = &ensea_leds_fops;

    ret_val = misc_register(&dev->miscdev);
    if(ret_val != 0) {
        pr_info("Couldn't register misc device :(");
        goto bad_exit_return;
    }

    // Give a pointer to the instance-specific data to the generic platform_device structure
    // so we can access this data later on (for instance, in the read and write functions)
    platform_set_drvdata(pdev, (void*)dev);

    pr_info("leds_probe exit\n");

    return 0;

bad_ioremap:
   ret_val = PTR_ERR(dev->regs);
bad_exit_return:
    pr_info("leds_probe bad exit :(\n");
    return ret_val;
}

static int leds_remove(struct platform_device *pdev)
{
    // Grab the instance-specific information out of the platform device
    struct ensea_leds_dev *dev = (struct ensea_leds_dev*)platform_get_drvdata(pdev);

    pr_info("leds_remove enter\n");

    // Turn the LEDs off
    iowrite32(0x00, dev->regs);

    // Unregister the character file (remove it from /dev)
    misc_deregister(&dev->miscdev);

    pr_info("leds_remove exit\n");

    return 0;
}

static struct platform_driver leds_platform = {
    .probe = leds_probe,
    .remove = leds_remove,
    .driver = {
        .name = "Ensea LEDs Driver",
        .owner = THIS_MODULE,
        .of_match_table = ensea_leds_dt_ids
    }
};






// ------ Code ------

// callback timer
static void montimer(struct timer_list *t)
{
    // callback du timer
    ledState = 1 - ledState;
    // printk(KERN_INFO "ledState : %d\r\n", ledState);

    /* Il faut réarmer le timer si l'on veut un appel périodique */
    mod_timer(&timer, jiffies + speed_param);
}

// fonction initialisation module
static int module_final_init(void)
{
    int ret_val = 0;
    // creation de /proc/ensea/speed et /proc/ensea/dir
    ensea_entry = proc_mkdir(ensea_name, ensea_entry);
    speed_entry = proc_create(speed_name, 0666, ensea_entry, &speed_fops);
    dir_entry = proc_create(dir_name, 0666, ensea_entry, &dir_fops);

    // Register our driver with the "Platform Driver" bus
    ret_val = platform_driver_register(&leds_platform);
    if(ret_val != 0) {
        pr_err("platform_driver_register returned %d\n", ret_val);
        return ret_val;
    }

    // timer
    setup_timer(&timer, montimer, 0);
    mod_timer(&timer, jiffies + speed_param);

    // printk(KERN_INFO "module chargé, timer démarré\r\n");
    return 0;
}

// fonction de sortie module
void module_final_exit(void)
{
    // remove les direction crées plus haut dans proc
    remove_proc_entry(speed_name, speed_entry);
    remove_proc_entry(ensea_name, ensea_entry);
    remove_proc_entry(dir_name, dir_entry);

    // unregister platform device
    platform_driver_unregister(&leds_platform);
    printk(KERN_INFO "Ensea LEDs module successfully unregistered\n");

    // supp le timer
    del_timer(&timer);

    printk(KERN_ALERT "Bye bye...\n");
    printk(KERN_INFO "module déchargé\r\n");
}

module_param(dir_param, int, 0);
MODULE_PARM_DESC(dir_param, "Un autre paramètre de ce module");

module_param(speed_param, int, 0);
MODULE_PARM_DESC(speed_param, "Un paramètre de ce module");

module_init(module_final_init);
module_exit(module_final_exit);

MODULE_LICENSE(DRIVER_LICENSE);
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);

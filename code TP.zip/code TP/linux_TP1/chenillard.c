#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_LED 8
#define ON 1
#define OFF 0

int ecrit_led(uint8_t led_number, int state)
{
    char file_name[80];
    sprintf(file_name, "/sys/class/leds/fpga_led%d/brightness", led_number);
    FILE *fid = fopen(file_name, "w+");
    if (fid == NULL)
    {
        printf("LED %d : erreur ouverture fichier\r\n",led_number);
        return 1;
    }
    else
    {
        fprintf(fid, "%d", state);
    }
    fclose(fid);
    return 0;
}

int chenillard(int delay)
{
    uint8_t i=0;
    while(1){

        //nouvelle version
        /*ecrit_led(i,ON);
        if(i<8-nb_between){
            ecrit_led(i-nb_between,0);
        }
        else if ((i>8-nb_between)&&(i<MAX_LED)){
            ecrit_led(i-nb_between)
        }
    */

        for(int i=1;i<MAX_LED+1;i++){
        ecrit_led(i,ON);
        sleep(delay);
        }

        for(int i=1;i<MAX_LED+1;i++){
        ecrit_led(i,OFF);
        sleep(delay);
        }
    }
    return 0;
}


int main(int argc, char **argv)
{
    chenillard(atoi(argv[1]));
    return 0;
}
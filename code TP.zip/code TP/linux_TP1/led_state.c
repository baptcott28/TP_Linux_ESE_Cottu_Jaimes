#include <stdio.h>
#include <stdlib.h>

int ecrit_led(int led_number, int state){
    char file_name[80];
    sprintf(file_name,"/sys/class/leds/fpga_led%d/brightness",led_number);
    FILE * fid = fopen(file_name,"w+");
    if (fid==NULL){
        printf("erreur ouverture fichier\r\n");
        return 1;
    }
    else{
        printf("fichier ouvert\r\n");
        fprintf(fid,"%d",state);
    }
    fclose(fid);
    return 0;
}


int main(int argc, char ** argv){
    ecrit_led(atoi(argv[1]),atoi(argv[2]));
    return 0;
}